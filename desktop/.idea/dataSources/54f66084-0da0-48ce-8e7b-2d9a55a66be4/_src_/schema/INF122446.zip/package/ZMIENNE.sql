create package zmienne is
vLicznik Number := 0;
procedure ZwiekszLicznik;
procedure ZmniejszLicznik;
function PokazLicznik return Number;
end zmienne;