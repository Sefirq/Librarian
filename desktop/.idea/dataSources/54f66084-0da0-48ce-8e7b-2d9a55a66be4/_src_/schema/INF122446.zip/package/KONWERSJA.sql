create package konwersja is
  function cels_to_fahr(c Number) return Number;
  function fahr_to_cels(f Number) return Number;
end konwersja;