create package modyfikacje is
  procedure dodajKolumne(rel Varchar, kol Varchar, typ Varchar);
   procedure usunKolumne(rel Varchar, kol Varchar);
  procedure zmienTypKolumny(rel Varchar, kol Varchar, typ Varchar, zac Boolean);
 end modyfikacje;