create FUNCTION funLiczEtaty
Return Integer
AUTHID CURRENT_USER
Is co Integer;
begin
select count(*) Into co from etaty;
return(co);
End;