create procedure procPokazTest
authid current_user
is
begin
  FOR c_rec IN ( SELECT tekst FROM inf122446.test ) LOOP
    dbms_output.put_line(c_rec.tekst);
  end loop;
end;