create function PLACA_NETTO(k Number, p Number default 20)
return Number is
begin
  return k * 100 / (100 + p);
end;