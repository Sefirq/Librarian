create FUNCTION ile_wypozyczonych(library_id NUMBER, branch_number NUMBER)
  RETURN NUMBER IS
  v_number NUMBER;
  BEGIN
    SELECT count(*)
    INTO v_number
    FROM l_wypożyczenia
      JOIN l_kopie
        ON (kopie_sygnatura = sygnatura)
    WHERE filie_numer = branch_number AND biblioteki_id = library_id
          AND data_Oddania IS NULL;
    RETURN v_number;
  END;