create procedure ileRekordow(rel Varchar) is
  c Number;
  s Long;
begin
  s := 'select count(*) from ' || rel;
  execute immediate s into c;
  dbms_output.put_line('Liczba rekordów relacji ' || rel || ': ' || c);
end ileRekordow;