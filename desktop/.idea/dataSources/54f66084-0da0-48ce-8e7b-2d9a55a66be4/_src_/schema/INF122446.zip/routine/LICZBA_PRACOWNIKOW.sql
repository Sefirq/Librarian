create procedure liczba_pracownikow(zespol VARCHAR, l_p OUT NUMBER) is
  cursor c(z VARCHAR) is select * from zespoly where nazwa = z;
  cursor k(z VARCHAR) is select * from pracownicy join zespoly using(id_zesp) where nazwa = z;
  L NUMBER := 0;
begin
  for x in c(zespol) loop
    L := L + 1;
  end loop;
  if L = 0 then
    raise_application_error(20001, 'Brak zespolu o podanym numerze');
  end if;
  L := 0;
  for x in k(zespol) loop
    L := L + 1;
  end loop;
  l_p := L;
end;