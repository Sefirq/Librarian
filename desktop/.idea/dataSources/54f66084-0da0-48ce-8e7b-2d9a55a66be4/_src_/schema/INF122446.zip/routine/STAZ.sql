create function staz(d Date)
return Number is
  i Interval Year to Month;
  y Number;
begin
  i := (sysdate - d) Year to Month;
  y := extract(Year from i);
  return y;
end;