create PROCEDURE p IS

BEGIN

select * from pracownicy;

END;