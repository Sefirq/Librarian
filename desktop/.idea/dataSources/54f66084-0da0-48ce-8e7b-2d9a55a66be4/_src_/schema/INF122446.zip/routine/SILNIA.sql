create function silnia(n Number)
return Number is
begin
  if n = 0 then
    return 1;
  end if;
  return silnia(n - 1) * n;
end;