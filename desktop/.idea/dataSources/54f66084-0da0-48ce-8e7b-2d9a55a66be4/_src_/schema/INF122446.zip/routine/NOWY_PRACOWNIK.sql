create procedure nowy_pracownik(n VARCHAR, z VARCHAR, s VARCHAR, p NUMBER) is
  cursor c(ze VARCHAR) is select * from zespoly where nazwa = ze;
  cursor k(sz VARCHAR) is select * from pracownicy where nazwisko = sz;
  L NUMBER := 0;
  I NUMBER;
  I_s NUMBER;
  I_z NUMBER;
begin
  for x in c(z) loop
    L := L + 1;
  end loop;
  if L = 0 then
    raise_application_error(-20001, 'Brak zespolu');
  end if;
  L := 0;
  for x in k(s) loop
    L := L + 1;
  end loop;
  if L = 0 then
    raise_application_error(-20002, 'Brak szefa');
  end if;
  Select max(id_prac) into I from pracownicy;
  I := I + 10;
  select id_prac into I_s from pracownicy where nazwisko = s;
  select id_zesp into I_z from zespoly where nazwa = z;
  insert into pracownicy values(I, n, 'STAZYSTA', I_s, systimestamp, p, NULL, I_z);
end;