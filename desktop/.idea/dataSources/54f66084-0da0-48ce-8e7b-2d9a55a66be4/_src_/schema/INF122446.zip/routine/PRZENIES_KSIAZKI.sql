create PROCEDURE przenies_ksiazki
  (lib_id_from VARCHAR2, branch_num_from INTEGER,
   lib_id_to   VARCHAR2, branch_num_to INTEGER)
IS
  CURSOR copies IS
    SELECT *
    FROM INF122446.L_KOPIE
    WHERE Filie_Numer = branch_num_from AND Biblioteki_ID = lib_id_from
    FOR UPDATE OF FILIE_NUMER, BIBLIOTEKI_ID;
PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    FOR copy IN copies LOOP
      UPDATE inf122446.l_kopie
      SET Filie_Numer = branch_num_to, Biblioteki_ID = lib_id_to
      WHERE CURRENT OF copies;
    END LOOP;
    COMMIT;
  END przenies_ksiazki;