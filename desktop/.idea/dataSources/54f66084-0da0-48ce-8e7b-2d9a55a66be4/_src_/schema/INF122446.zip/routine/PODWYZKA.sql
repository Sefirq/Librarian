create procedure podwyzka(zespol NUMBER, procent NUMBER default 15) is
  cursor c(z NUMBER) is select * from zespoly where id_zesp = z;
  L NUMBER := 0;
begin
  for x in c(zespol) loop
    L := L + 1;
  end loop;
  if L = 0 then
    raise_application_error(-20001, 'Brak zespolu o podanym numerze');
  end if;
  update pracownicy set placa_pod = placa_pod *(1+procent/100) where id_zesp = zespol;
end;