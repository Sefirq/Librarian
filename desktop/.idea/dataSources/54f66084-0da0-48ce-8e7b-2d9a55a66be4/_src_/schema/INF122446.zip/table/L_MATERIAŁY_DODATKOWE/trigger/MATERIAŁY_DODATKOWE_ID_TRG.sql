create trigger MATERIAŁY_DODATKOWE_ID_TRG
	before insert
	on L_MATERIAŁY_DODATKOWE
	for each row
BEGIN :NEW.ID := Materiały_dodatkowe_ID_SEQ.NEXTVAL;
END;