create trigger WYPOŻYCZENIA_ID_TRG
	before insert
	on L_WYPOŻYCZENIA
	for each row
BEGIN :NEW.ID := Wypożyczenia_ID_SEQ.NEXTVAL;
END;