create trigger TŁUMACZE_ID_TRG
	before insert
	on L_TŁUMACZE
	for each row
BEGIN :NEW.ID := Tłumacze_ID_SEQ.NEXTVAL;
END;