create trigger EMP_TRG1
	before insert
	on EMP
	for each row
begin
                  if :new.empno is null then
                      select emp_seq.nextval into :new.empno from sys.dual;
                 end if;
              end;