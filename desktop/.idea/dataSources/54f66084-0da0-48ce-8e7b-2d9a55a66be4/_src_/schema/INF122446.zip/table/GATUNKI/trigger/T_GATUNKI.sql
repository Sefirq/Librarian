create trigger T_GATUNKI
	before insert or update
	on GATUNKI
	for each row
begin if inserting and :new."GATUNEK_ID" is null then 
  for c1 in (select "GATUNKI_SEQ".nextval nv from dual) loop 
     :new."GATUNEK_ID" := c1.nv;   end loop; end if; end;