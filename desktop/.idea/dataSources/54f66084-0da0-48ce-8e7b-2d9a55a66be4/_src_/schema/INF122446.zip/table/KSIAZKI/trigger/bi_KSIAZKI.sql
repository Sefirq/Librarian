create trigger "bi_KSIAZKI"
	before insert
	on KSIAZKI
	for each row
begin  
  if :new."ID" is null then
    select "KSIAZKI_SEQ".nextval into :new."ID" from sys.dual;
  end if;
end;
