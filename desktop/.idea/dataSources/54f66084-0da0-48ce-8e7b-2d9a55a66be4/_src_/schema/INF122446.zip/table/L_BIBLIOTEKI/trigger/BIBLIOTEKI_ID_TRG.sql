create trigger BIBLIOTEKI_ID_TRG
	before insert
	on L_BIBLIOTEKI
	for each row
BEGIN :NEW.ID := Biblioteki_ID_SEQ.NEXTVAL;
END;