create trigger KSIĄŻKI_ID_TRG
	before insert
	on L_KSIĄŻKI
	for each row
BEGIN :NEW.ID := Książki_ID_SEQ.NEXTVAL;
END;