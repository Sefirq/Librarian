create trigger BIBLIOTEKARZE_ID_TRG
	before insert
	on L_BIBLIOTEKARZE
	for each row
BEGIN :NEW.ID := Bibliotekarze_ID_SEQ.NEXTVAL;
END;