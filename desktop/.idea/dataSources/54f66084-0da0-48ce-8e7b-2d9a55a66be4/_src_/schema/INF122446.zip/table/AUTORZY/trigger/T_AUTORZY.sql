create trigger T_AUTORZY
	before insert or update
	on AUTORZY
	for each row
begin if inserting and :new."AUTOR_ID" is null then 
  for c1 in (select "AUTORZY_SEQ".nextval nv from dual) loop 
     :new."AUTOR_ID" := c1.nv;   end loop; end if; end;