create trigger AUTORZY_ID_TRG
	before insert
	on L_AUTORZY
	for each row
BEGIN :NEW.ID := Autorzy_ID_SEQ.NEXTVAL;
END;